package za.co.smartdealssa

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF137A45)
private val Ink = Color(0xFF17231C)
private val Muted = Color(0xFF66736B)
private val Pale = Color(0xFFF3F8F4)

data class Deal(
    val title: String,
    val category: String,
    val description: String,
    val price: String = "Check current price",
    val url: String = ""
)

// Replace these examples with products from an affiliate programme you have been approved for.
// Never publish invented prices, discounts, ratings or affiliate URLs.
private val starterDeals = listOf(
    Deal(
        "Car Jump Starter & Tyre Inflator",
        "Automotive",
        "Portable car jump starter with a tyre inflator. Check the retailer page for the latest price, specifications and availability.",
        price = "Check current price on Check It SA",
        url = "https://checkitsa.co.za/products/car-jump-starter-tyre-inflator?sca_ref=12731048.qYdMXHsZXknR"
    ),
    Deal("Wireless earphones", "Electronics", "Everyday audio accessory. Add a verified product and your approved affiliate link."),
    Deal("Power bank", "Electronics", "Useful for keeping a phone charged while travelling. Add a verified product link."),
    Deal("Kitchen storage set", "Home", "A practical home organisation idea. Add a verified product link."),
    Deal("Skincare starter kit", "Beauty", "A beauty product idea. Check ingredients and seller details before promoting."),
    Deal("Everyday backpack", "Fashion", "A useful everyday carry item. Add a verified product link.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartDealsApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartDealsApp() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    var selected by remember { mutableStateOf<Deal?>(null) }
    val categories = listOf("All", "Automotive", "Electronics", "Home", "Beauty", "Fashion", "Digital")

    val filtered = starterDeals.filter {
        (category == "All" || it.category == category) &&
        (it.title.contains(query, true) || it.description.contains(query, true))
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            onPrimary = Color.White,
            background = Pale,
            surface = Color.White,
            onSurface = Ink
        )
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Smart Deals SA", fontWeight = FontWeight.Bold, fontSize = 21.sp)
                            Text("Find useful deals. Share smart.", fontSize = 12.sp, color = Muted)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Pale)
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search products") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text("Browse categories", fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    categories.take(3).forEach { item ->
                        FilterChip(
                            selected = category == item,
                            onClick = { category = item },
                            label = { Text(item) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    categories.drop(3).forEach { item ->
                        FilterChip(
                            selected = category == item,
                            onClick = { category = item },
                            label = { Text(item) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Deals you can shop", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text("Check retailer pages for current prices and availability.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filtered) { deal ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { selected = deal },
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(deal.category.uppercase(), color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(deal.title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text(deal.description, color = Muted, fontSize = 13.sp)
                                Spacer(Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(deal.price, fontWeight = FontWeight.SemiBold, color = Ink, modifier = Modifier.weight(1f))
                                    Text("VIEW DETAILS  →", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    item {
                        Text(
                            "Disclosure: Smart Deals SA may earn a commission when you buy through an approved affiliate link. Prices and availability can change.",
                            color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 12.dp)
                        )
                    }
                }
            }
        }

        selected?.let { deal ->
            AlertDialog(
                onDismissRequest = { selected = null },
                title = { Text(deal.title) },
                text = {
                    Column {
                        Text(deal.description)
                        Spacer(Modifier.height(8.dp))
                        Text(deal.price, fontWeight = FontWeight.Bold)
                        if (deal.url.isBlank()) {
                            Text("This is a starter example. Add an approved affiliate URL before sharing.", color = Muted)
                        }
                    }
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (deal.url.isNotBlank()) {
                            TextButton(onClick = {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(deal.url)))
                            }) {
                                Text("Buy Now")
                            }
                        }
                        TextButton(onClick = {
                            val text = "${deal.title}\\n${deal.description}\\n${deal.price}\\n\\nAffiliate disclosure: I may earn a commission if you buy through my link."
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, if (deal.url.isBlank()) text else "$text\\n${deal.url}")
                            }
                            context.startActivity(Intent.createChooser(send, "Share deal"))
                        }) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Share")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selected = null }) { Text("Close") }
                }
            )
        }
    }
}
